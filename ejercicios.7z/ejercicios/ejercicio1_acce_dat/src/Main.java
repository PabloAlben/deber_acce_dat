import java.io.File;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String directorio;
        System.out.println("Dime el directorio");
        directorio = teclado.next();

        File file = new File(directorio);

        System.out.println(file.getName());


    }
}