import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        Scanner teclado = new Scanner(System.in);
        String directorio;
        String extension;
        int numext;
        ArrayList<Filtro> filtros = new ArrayList<>();
        System.out.println("Dime el directorio");
        directorio = teclado.next();

         do{
            System.out.println("Dime la extension");
            extension = teclado.next();
            filtros.add(new Filtro(extension));
            System.out.println(". si quieres otro");
        }while(teclado.next().equals("."));

        File file = new File(directorio);
       for (Filtro filtro : filtros) {
           for (File archivo : file.listFiles()) {
               if (filtro.accept(archivo)) {
                   System.out.println(archivo.getName());
               }
           }
       }
    }
}

