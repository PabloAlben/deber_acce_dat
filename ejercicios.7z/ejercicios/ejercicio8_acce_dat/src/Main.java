import java.io.*;
import java.nio.Buffer;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        String directorio;
        String texto;


        System.out.println("Dime el directorio");
        directorio = teclado.next();

        File file = new File(directorio);

        File copia = new File(directorio,file.getName()+"copia");

        System.out.println("fichero copia creado");

        try {
            FileReader filereader = new FileReader(file);

            System.out.println("fichero leido");
            FileWriter fileWriter = new FileWriter(copia);
            System.out.println("escritor de ficheros creado");
            BufferedReader bufferedReader = new BufferedReader(filereader);
            System.out.println("guardado en el buffer");
            while((texto = bufferedReader.readLine()) != null){

                fileWriter.write(texto);
                System.out.println("linea escrita");

            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        copia.delete();
        System.out.println("eliminado");


    }
}
