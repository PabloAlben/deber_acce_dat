package com.example.listaaccedat;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import org.xml.sax.SAXException;

import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class HelloController implements Initializable {

    @FXML
    private Button buttonNext;
    @FXML
    private Label label;
    @FXML
    private Button buttonPrevious;
    @FXML
    private TextField nombrefield;
    @FXML
    private TextField equipofield;
    @FXML
    private TextField añofield;
    @FXML
    private Text idtext;
    @FXML
    private TextField posicionfield;

    private GestionarXML gx;
    int posicion;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        gx = new GestionarXML();
        posicion = 0;

        try {
            FutbolistaPOJO fp = gx.LeerXML("futbolistas.xml").get(posicion);
            idtext.setText(idtext.getText() + fp.getId());
            nombrefield.setText(fp.getNombre());
            equipofield.setText(fp.getEquipo());
            añofield.setText(String.valueOf(fp.getAño()));
            posicionfield.setText(fp.getPosicion());
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    public void handleButtonActionNext(ActionEvent actionEvent) throws ParserConfigurationException, IOException, SAXException {
        posicion++;
        if (posicion < gx.LeerXML("futbolistas.xml").size()){
        idtext.setText("FUTBOLISTA: ");
        try {
            FutbolistaPOJO fp = gx.LeerXML("futbolistas.xml").get(posicion);
            idtext.setText(idtext.getText() + fp.getId());
            nombrefield.setText(fp.getNombre());
            equipofield.setText(fp.getEquipo());
            añofield.setText(String.valueOf(fp.getAño()));
            posicionfield.setText(fp.getPosicion());
        } catch (SAXException e) {
            throw new RuntimeException(e);
        } catch (ParserConfigurationException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR,"no hay siguiente");
            a.show();
        }
    }

    @FXML
    public void handleButtonActionPrevios(ActionEvent actionEvent) {
        if (posicion > 0) {
            posicion--;
            idtext.setText("FUTBOLISTA: ");
            try {
                FutbolistaPOJO fp = gx.LeerXML("futbolistas.xml").get(posicion);
                idtext.setText(idtext.getText() + fp.getId());
                nombrefield.setText(fp.getNombre());
                equipofield.setText(fp.getEquipo());
                añofield.setText(String.valueOf(fp.getAño()));
                posicionfield.setText(fp.getPosicion());
            } catch (SAXException e) {
                throw new RuntimeException(e);
            } catch (ParserConfigurationException e) {
                throw new RuntimeException(e);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }else{
            Alert a = new Alert(Alert.AlertType.ERROR,"no hay previo");
            a.show();
        }
    }

    @FXML
    public void handleButtonActionCreate(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionDelete(ActionEvent actionEvent) {
    }

    @FXML
    public void handleButtonActionUpdate(ActionEvent actionEvent) {
    }


}