import java.io.File;
import java.io.IOException;
import java.sql.Time;
import java.util.Date;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner teclado = new Scanner(System.in);
        File file;

       do {
         System.out.println("Dime el directorio");
         file = new File(teclado.next());
       }while(!file.exists() || !file.canWrite() || !file.canRead());

        System.out.println("que quieres hacer?");
        System.out.println("1-informacion");
        System.out.println("2-crear carpeta");
        System.out.println("3-crear fichero");
        System.out.println("4-eliminar");
        System.out.println("5-renombrar");

        switch (teclado.nextInt()){
            case 1:
                 metodo1(file);
                break;
            case 2:
                System.out.println("donde lo quieres");
                metodo2(teclado.next());

                break;
            case 3:
                System.out.println("donde lo quieres");
                metodo3(teclado.next());
                break;
            case 4:

                System.out.println("deime el fichero/directorio (no elimina directorios con algo dentro)");
                metodo4(teclado.next());

                break;
            case 5:
               System.out.println("dime el nombre");
               String nombre = teclado.next();
               metodo5(file,nombre);

                break;
            default:
                System.out.println("No valido");
        }
    }

    public static void metodo1(File file){

        System.out.println("Nombre: " + file.getName());
        if (file.isDirectory()) {
            System.out.println("Tipo: Directorio");
            System.out.println("Numero de archivos: " + file.list().length);
            System.out.println("Espacio libre: " + file.getFreeSpace());
            System.out.println("Espacio disponible: " + file.getUsableSpace());
            System.out.println("Espacio total: " + file.getTotalSpace());

        } else if (file.isFile()) {
            System.out.println("Tipo: Fichero");
            System.out.println("Tamaño en Bytes: " + file.getTotalSpace());
        }
        System.out.println("Ubicacion: " + file.getAbsoluteFile());
           Date d = new Date(file.lastModified());
        System.out.println("Ultima Modificacion: " + d.toString());

        if (file.isHidden()) {
            System.out.println("esta oculto");
        } else{
            System.out.println("No es oculto");
        }

    }

    public static void metodo2(String directorio){

        File f = new File(directorio);

        if(f.mkdir()){
            System.out.println("directorio creado en: " + f.getAbsolutePath());
        }

    }

    public static void metodo3(String directorio){

        File f = new File(directorio);

        try {
            if (f.createNewFile()){
                System.out.println("fichero creado en: " + f.getAbsolutePath());
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void metodo4(String directorio){

        File f = new File(directorio);

        if (f.delete()){
            System.out.println("eliminado correctamente");
        }
    }
    public static void metodo5(File file, String nombre){

       File nuevo = new File(nombre);

       if(file.renameTo(nuevo)){
           System.out.println("nombre cambiado exitosamente");
       }else{
           System.out.println("error");
       }

    }
    
}