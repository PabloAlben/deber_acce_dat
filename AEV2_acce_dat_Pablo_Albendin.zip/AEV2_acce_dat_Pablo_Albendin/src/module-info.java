/**
 * 
 */
/**
 * 
 */
module AEV2_acce_dat_Pablo_Albendin {
	requires java.desktop;
}