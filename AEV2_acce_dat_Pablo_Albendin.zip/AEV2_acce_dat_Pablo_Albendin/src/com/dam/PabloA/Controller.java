package com.dam.PabloA;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Controller {
	
	
	 Model model;
	 Vista1 vista;
	 
	 
	 public Controller(Model model, Vista1 vista) {
		 this.model = model;
		 this.vista = vista;
		 
		 Texto_original();
		
	 }
	 
	 public void Texto_original() {
		 
		 ArrayList<String> mostrar = model.leer();
		 String resultado = String.join("\n", mostrar);
		 vista.getTextAreaOriginal().setText(resultado);
		 
		 vista.getBtnBuscar().addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent arg0) {
				 if(vista.getTextFieldBuscar().getText().isEmpty()) {
					  JOptionPane.showMessageDialog(new JFrame(),"No hay nada en buscar","ERROR", JOptionPane.ERROR_MESSAGE); 
				  }else {
				   String palabra = vista.getTextFieldBuscar().getText();  
				   JOptionPane.showMessageDialog(new JFrame(),"-Palabra: " + palabra +" -Total: "+ model.Buscar(palabra),"RESULTADO", JOptionPane.INFORMATION_MESSAGE); 
					
				  }
		}
		 });
		 
		vista.getBtnReemplazar().addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
			
				  if(vista.getTextFieldBuscar().getText().isEmpty()) {
					  JOptionPane.showMessageDialog(new JFrame(),"No hay nada en buscar","ERROR", JOptionPane.ERROR_MESSAGE); 
				  }else{
					  ArrayList<String> resultado = model.remplazar(vista.getTextFieldBuscar().getText(),vista.getTextFieldReemplazar().getText());
					  String mostrar = String.join("\n", resultado);
					  vista.getTextAreaModificado().setText(mostrar);
					  
				  }
				  
			}
		});

	 }
	 
	
}
