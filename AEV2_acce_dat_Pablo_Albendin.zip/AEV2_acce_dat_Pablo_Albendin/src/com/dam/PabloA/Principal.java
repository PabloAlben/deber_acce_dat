package com.dam.PabloA;

public class Principal {

	public static void main(String[] args) {
		
		
		Vista1 vista = new Vista1();
		Model modelo = new Model();
		Controller controller = new Controller(modelo, vista);
		

	}

}
