package com.dam.PabloA;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class Model {
	
	private File archivo = new File ("AE02_T1_2_Streams_Groucho.txt");
	
	public Model() {
		
	}
	
	public ArrayList<String> leer() {
		
		ArrayList<String> resultado = new ArrayList<String>(); 
		
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
			
			
			String linea = br.readLine();
		    while(linea != null){
		    
		    	resultado.add(linea);
		    	linea = br.readLine();

		    	
		    }
			
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		return resultado;
	} 
	
    public int Buscar(String palabra) {
    	
		int resultado = 0;
		String [] comprobar;
		
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
				
			String linea = br.readLine();
		    while(linea != null){
		          comprobar = linea.split(" ");
		          for(int i = 0;i<comprobar.length;i++) {
		        	  if(comprobar[i].equals(palabra)) {
		        		  resultado++;
		        	  }
		          }
		          linea = br.readLine();  
		    }
			
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		return resultado;
	}
	
    public ArrayList<String> remplazar(String palabra, String nueva) {
    	
    	ArrayList<String> resultado = new ArrayList<String>(); 
		String [] comprobar;
		String juntar = "";
		try {
			FileReader fr = new FileReader(archivo);
			BufferedReader br = new BufferedReader(fr);
				
			String linea = br.readLine();
		    while(linea != null){
		          comprobar = linea.split(" ");
		          for(int i = 0;i<comprobar.length;i++) {
		        	  if(comprobar[i].equals(palabra)) {
		        		  comprobar[i] = nueva;
		        	  }
		        	  
		          }
		          for(int i = 0;i<comprobar.length;i++) {
		        	  juntar += comprobar[i];
		          }
		          
		          resultado.add(juntar);
		          juntar = "";
		          linea = br.readLine();  
		    }
		    
		    crear_archivo(resultado);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
				
		return resultado;
	}

    
    public boolean crear_archivo(ArrayList<String> escribir) {
    	
    	File escrito = new File("escrito.txt");
    	
    	try {
			FileWriter fw = new FileWriter(escrito);
			BufferedWriter bw = new BufferedWriter(fw);
			
			for (String string : escribir) {
				bw.write(string);
				bw.newLine();
			
			}
			
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	return false;
    }
    
}
